<?php
$x = "Hello World";
$y = "Hello world";

echo $x;
echo "<br>";
echo $y;

$a = 5989;
var_dump($a);

$b = 10.365;
var_dump($b);

$cars = array("Volvo","BMW","Toyota");
var_dump($cars);

$a1 = "Hello world!";
$a1 = null;
var_dump($a1);

$b = 10.365;
var_dump($b);

$cars = array("Volvo","BMW","Toyota");
var_dump($cars);

$a1 = "Hello world";
$a1 = null;
var_dump($a1);

?>
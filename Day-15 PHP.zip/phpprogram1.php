<?php
    $silveroak="Hello";
    $a=20;
    $b="How are you?";

    $x = 10;
    $y = 20;
    $sum = $x + $y;
    $sub = $x - $y;
    $mul = $x * $y;
    $div = $x / $y;
    $div1 = $y / $x;
    $div2 = (float) ($x/$y);


    echo $silveroak . "<br/>";
    echo $a . "<br/>";
    echo $b . "<br/>";
    
    
    echo "sum=" . $sum . "<br/>";
    echo "sub=" . $sub . "<br/>";
    echo "mul=" . $mul . "<br/>";
    echo "div=" . $div . "<br/>";
    echo "div1=" . $div1 . "<br/>";
    echo "div2=" . $div2 . "<br/>";

    var_dump($sum) . "<br/>";
    var_dump("Heloooo") . "<br/>";

?>
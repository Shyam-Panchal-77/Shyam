<?php
// PHP code to check whether the number 
// is Even or Odd in Normal way
function check($number){
    if($number % 2 == 0){
        echo "Even"; 
    }
    else{
        echo "Odd";
    }
}
  
// Driver Code
$number = 39;
check($number)
?>
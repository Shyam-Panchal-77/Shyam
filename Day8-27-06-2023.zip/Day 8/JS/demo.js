function demoExternalAlert() 
{
    alert("Internal Alert");
}
function demoExternalConfirm(){
    if(confirm("Are you sure")){
        alert("YESSS..!!");
    }
    else{
        alert("NOO");
    
}
}
function demoExternalPrompt(){
    var fName=prompt("Enter Firstname Here...");
    var lname=prompt("Enter Lastname here..");
    alert(fName+ "" +lName);
}
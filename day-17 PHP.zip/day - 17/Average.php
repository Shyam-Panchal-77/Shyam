<?php
    $i=1;
    $j=0;
    while($i<=10)
    {
        $j+=$i;
        $i++;
    }
    echo "Average of 10 sequential no.s,starts form 1 is ".($j/10);
?>
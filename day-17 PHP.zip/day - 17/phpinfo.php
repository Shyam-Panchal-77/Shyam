<?php

    echo phpinfo();

?>

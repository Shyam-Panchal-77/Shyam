<?php
echo "The Orignal Array Is:<br>";
$a = array("Krushi","Moru","Dev","Meet");
echo "<pre>";
print_r($a);
echo "After nothing...<br>";
sort($a);
echo"<pre>";
print_r($a);
?>
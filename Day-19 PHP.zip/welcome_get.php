<html>  
   <body>  
     
      Your Name : <?php echo $_GET["name"]; ?> </br>  
      Your Email is : <?php echo $_GET["email"]; ?>  
  
   </body>  
</html> 